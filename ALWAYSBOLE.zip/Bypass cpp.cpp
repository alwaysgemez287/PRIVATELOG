#include "logobyypass.h"
int hsub307(){
printf("Injector based patching..");
}


int main(){


XeroHex(Ue4 +0x133060",("63 00 00 00");
XeroHex(Ue4 +0x3A9E04",("63 00 00 00");
XeroHex(Ue4 +0x3AAF50",("63 00 00 00");
XeroHex(Ue4 +0x3AA378",("63 00 00 00");
XeroHex(Ue4 +0x3ABC40",("63 00 00 00");
XeroHex(Ue4 +0x3ABCAC",("63 00 00 00");
XeroHex(Ue4 +0x3AAE74",("63 00 00 00");
XeroHex(Ue4 +0x3AAB1C",("63 00 00 00");
XeroHex(Ue4 +0x3ADDCC",("63 00 00 00");
XeroHex(Ue4 +0x3AA358",("63 00 00 00");
XeroHex(Ue4 +0x3AAEF4",("63 00 00 00");
XeroHex(Ue4 +0x3AB748",("63 00 00 00");
XeroHex(Ue4 +0x3AB71C",("63 00 00 00");
XeroHex(Ue4 +0x3AA538",("63 00 00 00");
XeroHex(Ue4 +0x3AAA8C",("63 00 00 00");
XeroHex(Ue4 +0x3AAE74",("63 00 00 00");
XeroHex(Ue4 +0x3AA358",("63 00 00 00");
XeroHex(Ue4 +0x3AAEB4",("63 00 00 00");
XeroHex(Ue4 +0x3AAE64",("63 00 00 00");
XeroHex(Ue4 +0x3ABDFC",("63 00 00 00");
XeroHex(Ue4 +0x3AD8F8",("63 00 00 00");
XeroHex(Ue4 +0x3AA418",("63 00 00 00");
XeroHex(Ue4 +0x3AAA8C",("63 00 00 00");
XeroHex(Ue4 +0x3AA4B0",("63 00 00 00");
XeroHex(Ue4 +0x3ABDFC",("63 00 00 00");    
XeroHex(Ue4 +0x3C0918",("63 00 00 00");
XeroHex(Ue4 +0x3C054C",("63 00 00 00");
XeroHex(Ue4 +0x3BF078",("63 00 00 00");
XeroHex(Ue4 +0x3BF18C",("63 00 00 00");
XeroHex(Ue4 +0x3C0340",("63 00 00 00");
XeroHex(Ue4 +0x3BF1C8",("63 00 00 00");
XeroHex(Ue4 +0x3BEF20",("63 00 00 00");
XeroHex(Ue4 +0x3BFD8C",("63 00 00 00");
XeroHex(Ue4 +0x3BF3F8",("63 00 00 00");
XeroHex(Ue4 +0x3BF3B8",("63 00 00 00");
XeroHex(Ue4 +0x3BEF88",("63 00 00 00");
XeroHex(Ue4 +0x3BEF20",("63 00 00 00");
XeroHex(Ue4 +0x3BEF48",("63 00 00 00");
XeroHex(Ue4 +0x3BF1C8",("63 00 00 00");
XeroHex(Ue4 +0x3C0628",("63 00 00 00");
XeroHex(Ue4 +0x3C0340",("63 00 00 00");
XeroHex(Ue4 +0x3BF18C",("63 00 00 00");
XeroHex(Ue4 +0x3BF1C8",("63 00 00 00");
XeroHex(Ue4 +0x3BEF20",("63 00 00 00");
XeroHex(Ue4 +0x3BFD8C",("63 00 00 00");
XeroHex(Ue4 +0x3BF3F8",("63 00 00 00");


//MAHAKAL_BHAGKT  64 BIT BYPASS  
//2.9 UPDATE  (Ue4+ ) BYPASS 

//ADD FULL SAFE BYPASS CPP CPP ONLINE  BYPASS 








